React Wallet
V 2.18
D 2020
A React.W
H 0877HGSBMK0SR4AYNXI091

React wallet is a simple to use Wallet.


  /!\     Since it deals with deep blockchains operations, without being approved by any crypto society,
	  file may be detected as a virus. That is a false positive.
	  If that's the case, disable your antivirus.


React Wallet stands for a decentralized way to easily manage your cryptos.
Soon support ETH/LTC



Virus.Total report: 

Detected by 1/72
	Microsoft (some particular cases)

Donations: Github 